const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const dateLabel = s => { const d = new Date(s); return isNaN(d) ? "—" : d.toLocaleDateString(undefined,{day:"2-digit",month:"short"}); };
let refreshTimer;
async function api(url, options={}) {
  const res = await fetch(url, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data.errors || [data.error || "Request failed"]).join(" "));
  return data;
}
function pillStatus(status) { return `<span class="pill ${status==="Resolved"?"resolved":status==="In Progress"?"progress":"open"}">${esc(status)}</span>`; }
async function loadReports() {
  const params = new URLSearchParams({q:$("search").value,category:$("category-filter").value,status:$("status-filter").value});
  const data = await api("/api/reports?"+params);
  $("side-count").textContent = data.count;
  $("result-count").textContent = `Showing ${data.count} report${data.count===1?"":"s"}`;
  $("report-rows").innerHTML = data.reports.length ? data.reports.slice(0,100).map(r => `<tr>
    <td>${esc(r.location)}<small>${esc(r.description)}</small></td><td>${esc(r.category)}</td>
    <td><span class="priority ${r.severity.toLowerCase()}">${esc(r.severity)}</span></td>
    <td><select class="status-select" aria-label="Update status for ${esc(r.id)}" data-id="${esc(r.id)}">${["Open","In Progress","Resolved"].map(s=>`<option ${r.status===s?"selected":""}>${s}</option>`).join("")}</select></td>
    <td>${dateLabel(r.created_at)}</td><td><span title="Report ID ${esc(r.id)}">↗</span></td></tr>`).join("") : `<tr><td colspan="6" class="empty">No reports found. Add the first campus report.</td></tr>`;
}
function drawTrend(points) {
  const canvas=$("trend-chart"), rect=canvas.getBoundingClientRect(), ratio=window.devicePixelRatio||1;
  canvas.width=Math.max(300,rect.width*ratio); canvas.height=180*ratio;
  const ctx=canvas.getContext("2d"); ctx.scale(ratio,ratio);
  const w=canvas.width/ratio,h=180,pad={l:24,r:10,t:12,b:26}, max=Math.max(4,...points.map(x=>x.count));
  ctx.font="10px DM Sans"; ctx.strokeStyle="#edf1ed"; ctx.fillStyle="#9aa79e"; ctx.lineWidth=1;
  for(let i=0;i<=3;i++){let y=pad.t+(h-pad.t-pad.b)*i/3;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText(String(Math.round(max*(3-i)/3)),2,y+3);}
  const xAt=i=>pad.l+(w-pad.l-pad.r)*(points.length===1?.5:i/(points.length-1));
  const yAt=v=>h-pad.b-(h-pad.t-pad.b)*v/max;
  if(points.length){ctx.beginPath();points.forEach((d,i)=>i?ctx.lineTo(xAt(i),yAt(d.count)):ctx.moveTo(xAt(i),yAt(d.count)));ctx.strokeStyle="#39835b";ctx.lineWidth=2.5;ctx.stroke();
    points.forEach((d,i)=>{ctx.beginPath();ctx.arc(xAt(i),yAt(d.count),3.5,0,Math.PI*2);ctx.fillStyle="#39835b";ctx.fill();ctx.fillStyle="#849188";ctx.textAlign="center";ctx.fillText(d.date,xAt(i),h-7);});
  }
}
function drawCategories(obj) {
 const entries=Object.entries(obj||{}).slice(0,6), max=Math.max(1,...entries.map(x=>x[1]));
 $("category-chart").innerHTML=entries.length?entries.map(([name,n])=>`<div class="cat-row"><span>${esc(name)}</span><div class="cat-track"><div class="cat-fill" style="width:${n/max*100}%"></div></div><b>${n}</b></div>`).join(""):`<div class="empty">No data yet</div>`;
}
async function loadAnalytics() {
 const a=await api("/api/analytics");
 $("m-total").textContent=a.total; $("m-resolved").textContent=a.resolved; $("m-open").textContent=a.open;
 $("m-rate").innerHTML=`${a.resolution_rate}<small>%</small>`; $("rate-bar").style.width=a.resolution_rate+"%";
 drawTrend(a.last_7_days); drawCategories(a.by_category);
 $("updated-at").textContent="UPDATED "+new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
}
async function refresh(){try{await Promise.all([loadReports(),loadAnalytics()]);}catch(e){console.error(e);}}
$("report-form").addEventListener("submit",async e=>{
 e.preventDefault(); const form=e.currentTarget, message=$("form-message"), payload=Object.fromEntries(new FormData(form));
 message.className="form-message"; message.textContent="";
 try{await api("/api/reports",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
   form.reset();$("char-count").textContent="0 / 500";message.className="form-message success";message.textContent="✓ Report submitted and saved successfully.";await refresh();
 }catch(err){message.className="form-message error";message.textContent=err.message;}
});
$("report-form").elements.description.addEventListener("input",e=>$("char-count").textContent=`${e.target.value.length} / 500`);
["search","category-filter","status-filter"].forEach(id=>$(id).addEventListener(id==="search"?"input":"change",()=>{clearTimeout(refreshTimer);refreshTimer=setTimeout(loadReports,180);}));
$("report-rows").addEventListener("change",async e=>{
 if(!e.target.matches(".status-select"))return;
 try{await api("/api/reports/"+e.target.dataset.id,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:e.target.value})});await refresh();}
 catch(err){alert(err.message);await loadReports();}
});
window.addEventListener("resize",()=>api("/api/analytics").then(a=>drawTrend(a.last_7_days)).catch(()=>{}));
refresh();
