"""Campus Cleanliness Reporter — standard-library Python web server."""
from __future__ import annotations

from datetime import datetime, date, timedelta
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import csv
import io
import json
import math
import os
import re
import threading
import uuid

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_FILE = DATA_DIR / "reports.json"
STATIC_DIR = BASE_DIR / "static"
LOCK = threading.RLock()

CATEGORIES = {"Litter", "Waste Management", "Restroom", "Water", "Garden", "Classroom", "Other"}
SEVERITIES = {"Low", "Medium", "High", "Critical"}
STATUSES = {"Open", "In Progress", "Resolved"}
MAX_RECORDS = 10000


def ensure_store() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_FILE.exists():
        atomic_write([])


def atomic_write(records: list[dict]) -> None:
    """Write to a temporary file and atomically replace the JSON store."""
    DATA_DIR.mkdir(exist_ok=True)
    temp = DATA_FILE.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8") as handle:
        json.dump(records, handle, indent=2, ensure_ascii=False)
        handle.flush()
        os.fsync(handle.fileno())
    temp.replace(DATA_FILE)


def load_records() -> list[dict]:
    ensure_store()
    try:
        with DATA_FILE.open(encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, list):
            raise ValueError("Data file root must be a list")
        valid = []
        for item in data:
            if isinstance(item, dict) and all(k in item for k in
                    ("id", "location", "category", "severity", "status", "description", "reporter", "created_at")):
                valid.append(item)
        return valid
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
        # Preserve a damaged file for recovery and start with a clean store.
        if DATA_FILE.exists():
            backup = DATA_FILE.with_suffix(".corrupt-" + datetime.now().strftime("%Y%m%d%H%M%S") + ".json")
            DATA_FILE.replace(backup)
        atomic_write([])
        return []


def validate(payload: object) -> tuple[dict | None, list[str]]:
    if not isinstance(payload, dict):
        return None, ["Request body must be a JSON object."]
    errors = []
    def clean(field: str, limit: int, required: bool = True) -> str:
        value = payload.get(field, "")
        if not isinstance(value, str):
            errors.append(f"{field.replace('_', ' ').title()} must be text.")
            return ""
        value = re.sub(r"\s+", " ", value).strip()
        if required and not value:
            errors.append(f"{field.replace('_', ' ').title()} is required.")
        if len(value) > limit:
            errors.append(f"{field.replace('_', ' ').title()} must be {limit} characters or fewer.")
        return value

    location = clean("location", 80)
    category = clean("category", 40)
    severity = clean("severity", 10)
    description = clean("description", 500)
    reporter = clean("reporter", 60)
    if category and category not in CATEGORIES:
        errors.append("Choose a valid category.")
    if severity and severity not in SEVERITIES:
        errors.append("Choose a valid severity.")
    if errors:
        return None, errors
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    return {
        "id": uuid.uuid4().hex[:10].upper(),
        "location": location, "category": category, "severity": severity,
        "status": "Open", "description": description, "reporter": reporter,
        "created_at": now, "updated_at": now
    }, []


def analytics(records: list[dict]) -> dict:
    total = len(records)
    resolved = sum(r["status"] == "Resolved" for r in records)
    open_count = sum(r["status"] == "Open" for r in records)
    high = sum(r["severity"] in {"High", "Critical"} for r in records)
    severity_score = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}
    average = round(sum(severity_score.get(r["severity"], 0) for r in records) / total, 2) if total else 0
    def counts(field):
        result = {}
        for row in records:
            result[row.get(field, "Other")] = result.get(row.get(field, "Other"), 0) + 1
        return dict(sorted(result.items(), key=lambda x: (-x[1], x[0])))
    days = []
    today = date.today()
    for offset in range(6, -1, -1):
        day = today - timedelta(days=offset)
        count = 0
        for row in records:
            try:
                if datetime.fromisoformat(row["created_at"]).date() == day:
                    count += 1
            except (ValueError, KeyError, TypeError):
                pass
        days.append({"date": day.strftime("%a"), "count": count})
    return {
        "total": total, "resolved": resolved, "open": open_count,
        "high_priority": high, "resolution_rate": round(resolved / total * 100) if total else 0,
        "average_severity": average, "by_category": counts("category"),
        "by_location": counts("location"), "by_status": counts("status"),
        "by_severity": counts("severity"), "last_7_days": days
    }


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def log_message(self, fmt, *args):
        print("[CampusReporter] " + fmt % args)

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/reports":
            params = parse_qs(parsed.query)
            q = params.get("q", [""])[0].strip().lower()
            category = params.get("category", [""])[0]
            status = params.get("status", [""])[0]
            with LOCK:
                rows = load_records()
            rows = [r for r in rows if
                    (not q or q in " ".join(str(r.get(k, "")) for k in
                     ("location", "category", "severity", "status", "description", "reporter", "id")).lower())
                    and (not category or r["category"] == category)
                    and (not status or r["status"] == status)]
            rows.sort(key=lambda r: r.get("created_at", ""), reverse=True)
            return self.send_json({"reports": rows, "count": len(rows)})
        if parsed.path == "/api/analytics":
            with LOCK:
                rows = load_records()
            return self.send_json(analytics(rows))
        if parsed.path == "/api/export.csv":
            with LOCK:
                rows = load_records()
            output = io.StringIO()
            fields = ["id", "location", "category", "severity", "status", "description", "reporter", "created_at"]
            writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
            data = output.getvalue().encode("utf-8-sig")
            self.send_response(200)
            self.send_header("Content-Type", "text/csv; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="campus-cleanliness-report.csv"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if parsed.path == "/api/export.md":
            with LOCK:
                rows = load_records()
            summary = analytics(rows)
            lines = ["# Campus Cleanliness Reporter — Executive Summary", "",
                     f"Generated: {datetime.now().astimezone().isoformat(timespec='minutes')}", "",
                     "## Key metrics", "", f"- Total reports: {summary['total']}",
                     f"- Resolved: {summary['resolved']}", f"- Open: {summary['open']}",
                     f"- Resolution rate: {summary['resolution_rate']}%", "", "## Category breakdown", ""]
            lines += [f"- {name}: {count}" for name, count in summary["by_category"].items()] or ["- No reports recorded."]
            lines += ["", "## Report register", "", "| ID | Location | Category | Priority | Status | Date |", "|---|---|---|---|---|---|"]
            lines += [f"| {r['id']} | {r['location']} | {r['category']} | {r['severity']} | {r['status']} | {r['created_at'][:10]} |" for r in rows]
            data = ("\n".join(lines) + "\n").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/markdown; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="campus-cleanliness-summary.md"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if parsed.path == "/api/chart.png":
            with LOCK:
                rows = load_records()
            try:
                import matplotlib
                matplotlib.use("Agg")
                import matplotlib.pyplot as plt
                report = analytics(rows)
                labels = [item["date"] for item in report["last_7_days"]]
                values = [item["count"] for item in report["last_7_days"]]
                fig, ax = plt.subplots(figsize=(8, 4), dpi=150)
                ax.plot(labels, values, marker="o", linewidth=2, color="#28734f")
                ax.fill_between(range(len(values)), values, alpha=.12, color="#65a77f")
                ax.set_title("Campus Cleanliness Reports — Last 7 Days")
                ax.set_ylabel("Number of reports")
                ax.grid(axis="y", alpha=.2)
                fig.tight_layout()
                buffer = io.BytesIO()
                fig.savefig(buffer, format="png", bbox_inches="tight")
                plt.close(fig)
                data = buffer.getvalue()
            except ImportError:
                return self.send_json({"error": "Matplotlib is not installed. Run: python -m pip install matplotlib"}, 501)
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Disposition", 'attachment; filename="campus-cleanliness-trend.png"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if parsed.path == "/api/health":
            return self.send_json({"ok": True, "service": "Campus Cleanliness Reporter"})
        if parsed.path == "/":
            self.path = "/static/index.html"
        elif not parsed.path.startswith("/static/"):
            return self.send_json({"error": "Not found"}, 404)
        return super().do_GET()

    def do_POST(self):
        if urlparse(self.path).path != "/api/reports":
            return self.send_json({"error": "Not found"}, 404)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 12000:
                return self.send_json({"errors": ["Request size must be between 1 and 12000 bytes."]}, 400)
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            return self.send_json({"errors": ["Invalid JSON request body."]}, 400)
        record, errors = validate(payload)
        if errors:
            return self.send_json({"errors": errors}, 400)
        with LOCK:
            rows = load_records()
            if len(rows) >= MAX_RECORDS:
                return self.send_json({"errors": ["Storage limit reached. Export and archive older records."]}, 507)
            rows.append(record)
            atomic_write(rows)
        return self.send_json({"message": "Report saved successfully.", "report": record}, 201)

    def do_PATCH(self):
        match = re.fullmatch(r"/api/reports/([A-F0-9]+)", urlparse(self.path).path)
        if not match:
            return self.send_json({"error": "Not found"}, 404)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            return self.send_json({"errors": ["Invalid JSON request body."]}, 400)
        status = payload.get("status") if isinstance(payload, dict) else None
        if status not in STATUSES:
            return self.send_json({"errors": ["Choose a valid status."]}, 400)
        with LOCK:
            rows = load_records()
            target = next((r for r in rows if r["id"] == match.group(1)), None)
            if not target:
                return self.send_json({"error": "Report not found"}, 404)
            target["status"] = status
            target["updated_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
            atomic_write(rows)
        return self.send_json({"message": "Status updated.", "report": target})


if __name__ == "__main__":
    ensure_store()
    host, port = "127.0.0.1", 8000
    print("\n  CAMPUS CLEANLINESS REPORTER")
    print("  Local sustainability dashboard")
    print(f"\n  Open http://{host}:{port} in your browser")
    print("  Press Ctrl+C to stop the server.\n")
    try:
        ThreadingHTTPServer((host, port), Handler).serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped safely.")
