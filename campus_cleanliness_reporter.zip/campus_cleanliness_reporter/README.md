# Campus Cleanliness Reporter

A responsive browser dashboard backed by Python 3.10+ standard library. It supports campus issue reporting, defensive validation, JSON persistence, search/filtering, live analytics, status updates, and CSV export.

## Run it

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Run `python server.py`.
4. Open `http://127.0.0.1:8000` in your browser.

No pip packages are required for the dashboard. The interactive charts are drawn with the browser Canvas API. To enable downloadable Matplotlib PNG trend charts, install the optional dependency with `python -m pip install matplotlib`. The backend otherwise uses only the Python standard library.

## Automated tests

Run `python -m unittest discover -s tests -v`.

## Features mapped to the brief

- Interactive website interface with overview, report form, recent reports, and analytics.
- Input validation for required fields, types, allowed categories/severities, and length boundaries.
- JSON storage with atomic replacement; corrupted JSON is preserved as a timestamped backup and a clean store is initialized.
- Keyword, category, and status filtering.
- Analytics: totals, resolved/open counts, resolution rate, high-priority count, average severity, category/location/status distributions, and last-seven-day trend.
- CSV and Markdown executive-summary exports, Matplotlib PNG trend export (optional dependency), and in-table status updates.
- Threaded HTTP server, modular validation/persistence/analytics functions, and automated unit tests.

## Notes

This is a local demonstration app. It binds to `127.0.0.1` and is not deployed for public internet use. For a real campus deployment, add authentication/authorization, HTTPS, role-based access, backups, audit logging, and a production database. Google Fonts are optional; system fonts remain available offline.
