import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server

class ValidationTests(unittest.TestCase):
    def valid(self):
        return {"location":"Library Block A","category":"Litter","severity":"High",
                "description":"Overflowing bin near entrance","reporter":"Student"}

    def test_valid_record(self):
        row, errors = server.validate(self.valid())
        self.assertEqual(errors, [])
        self.assertEqual(row["status"], "Open")
        self.assertTrue(row["id"])

    def test_missing_required_field(self):
        payload = self.valid()
        payload["location"] = " "
        row, errors = server.validate(payload)
        self.assertIsNone(row)
        self.assertTrue(any("Location is required" in e for e in errors))

    def test_invalid_category(self):
        payload = self.valid()
        payload["category"] = "Made up"
        self.assertTrue(server.validate(payload)[1])

    def test_length_limit(self):
        payload = self.valid()
        payload["description"] = "x" * 501
        self.assertTrue(server.validate(payload)[1])

    def test_non_string_input(self):
        payload = self.valid()
        payload["reporter"] = 123
        self.assertTrue(server.validate(payload)[1])

class AnalyticsTests(unittest.TestCase):
    def test_empty_metrics(self):
        result = server.analytics([])
        self.assertEqual(result["total"], 0)
        self.assertEqual(result["resolution_rate"], 0)

    def test_aggregates(self):
        rows = [
            {"status":"Resolved","severity":"High","category":"Litter","location":"A","created_at":"2026-01-01T10:00:00"},
            {"status":"Open","severity":"Low","category":"Water","location":"B","created_at":"2026-01-01T10:00:00"}
        ]
        result = server.analytics(rows)
        self.assertEqual(result["total"], 2)
        self.assertEqual(result["resolved"], 1)
        self.assertEqual(result["resolution_rate"], 50)
        self.assertEqual(result["by_category"]["Litter"], 1)

if __name__ == "__main__":
    unittest.main(verbosity=2)
